#!/bin/bash

logfile="/boot/update/nhupd.log"
nh_root="/mnt/emmc_root/usr/local/nanohome/"
updatedir="/boot/update"

echo "Date:" $(date '+%d.%m.%Y %H:%M') > $logfile
echo "" >> $logfile
echo "copying files..." >> $logfile
echo "" >> $logfile

# File Copy
cp -v -R /tmp/nhupd/templates/* $nh_root/templates/ >> $logfile

echo "" >> $logfile
echo "update successfull" >> $logfile

rm -rf /tmp/nhupd